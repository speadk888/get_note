#!/bin/bash

Uninstall_bt_app()
{
	rm -rf /www/server/panel/static/bt_app
	rm -rf $pluginPath
}

if [ "${1}" == 'uninstall' ];then
	Uninstall_bt_app
fi
